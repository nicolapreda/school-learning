package Treno;

public class Vagone {
    private String codice;
    private int pesoVuoto;
    private String aziendaCostruttrice;
    private int annoCostruzione;
    public int getPesoVuoto() {
        return pesoVuoto;
    }

    public String getCodice() {
        return codice;
    }

    public void setCodice(String codice) {
        this.codice = codice;
    }

    public void setPesoVuoto(int pesoVuoto) {
        this.pesoVuoto = pesoVuoto;
    }

    public String getAziendaCostruttrice() {
        return aziendaCostruttrice;
    }

    public void setAziendaCostruttrice(String aziendaCostruttrice) {
        this.aziendaCostruttrice = aziendaCostruttrice;
    }

    public int getAnnoCostruzione() {
        return annoCostruzione;
    }

    public void setAnnoCostruzione(int annoCostruzione) {
        this.annoCostruzione = annoCostruzione;
    }


}



            
            