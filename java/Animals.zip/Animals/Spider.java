class Spider extends Animal {
    public Spider() {
        super(8);
    }

    public void eat() {
        System.out.println("Il ragno mangia insetti.");
    }
}
