public interface Pet {
    public String getName();
    public void setName(String name);
    public String play();
}
