
public class Fish extends Animal {
    public Fish() {
        super(0);
    }
    
    public void eat() {
        System.out.println("Il pesce sta mangiando.");
    }
    
    public void walk() {
        System.out.println("Il pesce non cammina.");
    }
}