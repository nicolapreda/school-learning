var ricerca = "rambo";
var pagina = 1;


fetch('https://api.themoviedb.org/3/search/movie?api_key=7dd3351fd7dcd7de4e6bcdd502b9a4e0&query=' + ricerca + '&page=' + pagina + "&include_adult=false&language=en-it")
    .then(response => response.json())
    .then(risposta => fai(risposta))
    .catch(err => console.log('Request Failed', err)); // gestisci gli errori

var container = document.getElementById('container');

function fai(risposta) {
    var b = 0
    console.log(risposta);
    risposta.results.forEach(a => {
        
        var card = document.createElement("div");
        var titolo = document.createElement("h5");
        titolo.classList.add("card-title");
        titolo.innerText = risposta.results[b].original_title;
        var descrizione = document.createElement("p");
        descrizione.classList.add("card-text");
        descrizione.innerText = risposta.results[b].overview;
        var valutazione = document.createElement("a");
        valutazione.classList.add("btn");
        valutazione.classList.add("btn-primary");
        valutazione.innerText = risposta.results[b].vote_average;
        var card_body = document.createElement("div");
        card_body.classList.add("card-body")
        card_body.appendChild(titolo);
        card_body.appendChild(descrizione);
        card_body.appendChild(valutazione);
        var immagine = document.createElement("img");
        if(a.backdrop_path != null)
            immagine.src = "https://image.tmdb.org/t/p/original" + risposta.results[b].backdrop_path;
        else
            immagine.src = "./assets/undefined.png";
        immagine.classList.add("card-img-top");
        immagine.alt = "Copertina";
        var card = document.createElement("div");
        card.classList.add("card");
        card.classList.add("col-4");
        card.classList.add("p-2");
        card.appendChild(immagine);
        card.appendChild(card_body);
        document.getElementById("container").appendChild(card);
        b++;
    });
}